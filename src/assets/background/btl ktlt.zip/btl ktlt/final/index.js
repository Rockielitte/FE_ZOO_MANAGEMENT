
const express = require('express');
const app = express();
const port = 3001;
const mysql = require('mysql');
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

const connection = mysql.createConnection({
  host: 'localhost',         
  user: 'newuser',          
  password: 'password',      
  database: 'mydatabase',  
});

connection.connect((error) => {
  if (error) {
    console.error('Lỗi kết nối:', error);
    return;
  }
  console.log('Kết nối thành công!');
});

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/signup.html');
});

app.use(express.static('public'));

app.listen(port, () => {
  console.log(`Server đang chạy tại http://localhost:${port}`);
})

app.post('/register', (req, res) => {
  const { username, password } = req.body;
  connection.query('SELECT * FROM customers WHERE username = ?', [username], (err, results) => {
    if (err) {
      res.status(500).json({ error: 'Lỗi server' });
      return;
    }
    if (results.length > 0) {
      res.status(400).json({ error: 'Tên đăng nhập đã tồn tại!' });
      return;
    }
    connection.query('INSERT INTO customers (username, password) VALUES (?, ?)', [username, password], (err, results) => {

      if (err) {
        res.status(500).json({ error: 'Lỗi server' });
        console.log(err)
        return;
      }
      res.status(200).json({ message: 'Đăng ký thành công' });
    });
  });
});

app.post('/login', (req, res) => {
  const username = req.body.username;
  const password = req.body.password;
  connection.query('SELECT * FROM customers WHERE username = ? AND password = ?', [username, password], (err, result) => {
    if (err) {
      res.status(500).send('Lỗi server');
    } else {
      if (result.length > 0) {
        res.redirect('./index.html')
      } else {
        res.send('Sai tên đăng nhập hoặc mật khẩu');
      }
    }
  });
});