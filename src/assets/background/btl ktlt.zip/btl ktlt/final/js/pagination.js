function page(trang) {
    // Chuyển trang dựa vào trang được truyền vào
    if (trang === 1) {
      window.location.href = "index.html";
    } else if (trang === 2) {
      window.location.href = "page2.html";
    } else if (trang === 3) {
      window.location.href = "page3.html";
    }
  }