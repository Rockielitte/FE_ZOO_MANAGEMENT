var scrollButton = document.getElementById("scrollButton");

scrollButton.addEventListener("click", function() {
  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });
});

window.addEventListener("scroll", function() {
  if (window.pageYOffset > 0) {
    scrollButton.style.display = "block";
  } else {
    scrollButton.style.display = "none";
  }
});

scrollButton.addEventListener("mouseover", function() {
  scrollButton.style.opacity = 1;
});

scrollButton.addEventListener("mouseout", function() {
  scrollButton.style.opacity = 0.5;
});
