const slider = document.querySelector(".slider");
const sliderMain = document.querySelector(".slider-main");
const sliderItems = document.querySelectorAll(".slider-item");
const nextBtn = document.querySelector(".slider-next");
const prevBtn = document.querySelector(".slider-prev");
const dotItems = document.querySelectorAll(".slider-dot-item");
let sliderItemWidth = sliderItems[0].offsetWidth;
const slidersLength = sliderItems.length;
let positionX = 0;
let index = 0;

nextBtn.addEventListener("click", function () {
    handleChangeSlide(1);
});

prevBtn.addEventListener("click", function () {
    handleChangeSlide(-1);
});

function handleChangeSlide(direction) {
    if (direction === 1) {
        if (index >= slidersLength - 1) {
            index = slidersLength - 1;
            console.log("next");
            return;
        }
        index++;
    } else if (direction === -1) {
        if (index <= 0) {
            index = 0;
            console.log("prev");
            return;
        }
        index--;
    }

    sliderItemWidth = parseInt(window.getComputedStyle(sliderItems[index]).width);
    positionX = -index * sliderItemWidth;
    sliderMain.style.transform = `translateX(${positionX}px)`;

    // Update active dot
    dotItems.forEach((item) => item.classList.remove("active"));
    dotItems[index].classList.add("active");
}
