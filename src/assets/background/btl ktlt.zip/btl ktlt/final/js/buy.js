const btn = document.querySelectorAll(".buy")

// console.log(btn)
btn.forEach(function(button,index){
button.addEventListener("click", function(event){{
    var btnItem = event.target
    var btnbody = btnItem.parentElement
    var product = btnbody.parentElement
    var productImg = product.querySelector("img").src
    var productName = product.querySelector("h5").innerText
    var productPrice = product.querySelector("span").innerText
    console.log(productImg, productName, productPrice)
    addcart(productImg,productName,productPrice)
}})
})
function addcart(productImg,productName,productPrice){
    var addtr = document.createElement("tr")
    var cartItem = document.querySelectorAll("tbody tr")
    for (var i=0;i<cartItem.length;i++){
        var productT = document.querySelectorAll(".title")
        if(productT[i].innerHTML == productName){
            alert("Sản phẩm của bạn đã có trong giỏ hàng")
            return
        }
    }
    var trcontent ='<tr><td style="display: flex;align-items: center;"><img style="width: 70px; margin-right:10px" src="'+productImg+'" alt=""><span class="title">'+productName+'</span></td><td><p><span class="prices">'+productPrice+'</span></p></td><td><input style="width: 30px;outline: none;" type="number" value="1" min="0"></td><td style="cursor: pointer;"><span class="cart-delete">Xoá</span></td></tr>'
    addtr.innerHTML = trcontent
    var carTable = document.querySelector("tbody")
    carTable.append(addtr)
    carttotal()
    deleteCart()
}
function carttotal(){
    var cartItem = document.querySelectorAll("tbody tr")
    var totalC = 0
    for (var i=0;i<cartItem.length;i++){
        var inputValue = cartItem[i].querySelector("input").value
        // console.log(inputValue)
        var producPrice = cartItem[i].querySelector(".prices").innerHTML
        // console.log(producPrice)
        totalA = inputValue*producPrice*1000
        // totalB = totalA.toLocaleString('de-DE')
        // console.log(totalB)
        totalC = totalC + totalA
        // totalD = totalC.toLocaleString('de-DE')
    }
    var carTotalA = document.querySelector(".price-total span")
    var cartPrice = document.querySelector(".btn-buy span")
    carTotalA.innerHTML = totalC.toLocaleString("de-DE")
    cartPrice.innerHTML = totalC.toLocaleString("de-DE")
    inputchange()
}
function deleteCart(){
    var cartItem = document.querySelectorAll("tbody tr")
    for (var i=0;i<cartItem.length;i++){
        var productT = document.querySelectorAll(".cart-delete")
        productT[i].addEventListener("click", function(event){
            var cartDelete = event.target
            var cartitemR = cartDelete.parentElement.parentElement
            cartitemR.remove()
            carttotal()
        })
        
    }
}
function inputchange(){
    var cartItem = document.querySelectorAll("tbody tr")
    for (var i=0;i<cartItem.length;i++){
        var inputValue = cartItem[i].querySelector("input")
        inputValue.addEventListener("change", function(){
            carttotal()
        })
        
    }
}
const cartbtn = document.querySelector(".ti-close")
const carshow = document.querySelector(".btn-buy")
carshow.addEventListener("click", function(){
    document.querySelector(".cart").style.right = "0"
    console.log(carshow)
})
cartbtn.addEventListener("click", function(){
    document.querySelector(".cart").style.right = "-100%"
    console.log(cartbtn)
})
const checkBill = document.querySelector(".checkBill")
checkBill.addEventListener("click", function(event){
     alert("Thanh toán thành công")
     carttotal(0)
})